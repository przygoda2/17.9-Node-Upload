var server = require('./modules/server');
server.start();